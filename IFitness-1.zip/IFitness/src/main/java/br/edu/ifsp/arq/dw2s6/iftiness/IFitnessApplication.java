package br.edu.ifsp.arq.dw2s6.iftiness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IFitnessApplication {

	public static void main(String[] args) {
		SpringApplication.run(IFitnessApplication.class, args);
	}

}
