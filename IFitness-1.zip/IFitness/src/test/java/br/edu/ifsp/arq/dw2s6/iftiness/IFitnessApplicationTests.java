package br.edu.ifsp.arq.dw2s6.iftiness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IFitnessApplicationTests {

	@Test
	void contextLoads() {
	}

}
