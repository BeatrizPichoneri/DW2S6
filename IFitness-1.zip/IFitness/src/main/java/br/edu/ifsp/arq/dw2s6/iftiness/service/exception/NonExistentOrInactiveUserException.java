package br.edu.ifsp.arq.dw2s6.iftiness.service.exception;

public class NonExistentOrInactiveUserException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
